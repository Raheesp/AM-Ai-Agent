"""
main.py — Sara FastAPI server

Routes:
  GET  /                        → Dashboard UI
  POST /chat                    → Universal chat endpoint
  POST /webhook/telegram        → Telegram webhook
  GET  /webhook/whatsapp        → WhatsApp verify
  POST /webhook/whatsapp        → WhatsApp messages
  GET  /conversations           → List all conversations
  GET  /conversations/{phone}   → Conversation history
  POST /agent/create            → Save/update agent config
  GET  /agent/list              → List agents
  POST /resources/upload        → Upload knowledge-base file
  GET  /resources/list          → List resources
  DELETE /resources/{id}        → Delete a resource
  GET  /incentive/search        → Search employee by name
  GET  /incentive/employee/{code} → Get employee incentive
"""
import traceback
import json
import os
from datetime import datetime
from pathlib import Path
from app.ollama_client import chat as ollama_chat
from fastapi import FastAPI, Request, HTTPException, UploadFile, File, Form, Query
from fastapi.responses import HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()

from app import db
from app.chat_handler import handle_message
from app.incentive_engine import (
    search_by_name, search_by_emp_code,
    current_month_incentive, last_n_months_incentive,
)
from app.resource_manager import process_and_save_resource
from app.ollama_client import chat
from app.tts import text_to_speech_malayalam
"""from app.chat_handler import detect_intent"""

BASE_URL = "https://unrhetorically-unbrazen-earl.ngrok-free.dev"
# ── Boot ──────────────────────────────────────────────────────────────────────

db.init_db()

AGENT_CONFIG_PATH = os.getenv("AGENT_CONFIG", "agent_config.json")
RESOURCES_DIR = os.getenv("RESOURCES_DIR", "resources")
os.makedirs(RESOURCES_DIR, exist_ok=True)

app = FastAPI(title="Sara AI Agent", version="2.0.0")
from fastapi.staticfiles import StaticFiles

app.mount("/static", StaticFiles(directory="static"), name="static")

templates_dir = Path("app/templates")
templates_dir.mkdir(parents=True, exist_ok=True)
templates = Jinja2Templates(directory=str(templates_dir))


def load_agents() -> dict:
    if os.path.exists(AGENT_CONFIG_PATH):
        with open(AGENT_CONFIG_PATH) as f:
            return json.load(f)
    return {}


def get_agent(name: str = "Sara") -> dict:
    agents = load_agents()
    return agents.get(name, agents.get(list(agents.keys())[0], {})) if agents else {}


# ── Models ────────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    phone: str
    message: str
    channel: str = "api"
    agent: str = "Sara"


class AgentCreateRequest(BaseModel):
    name: str
    language: str = "Malayalam"
    model: str = "llama3.1:latest"
    description: str = ""
    system_prompt: str = ""
    channels: list[str] = ["whatsapp", "telegram"]


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    agents = load_agents()
    resources = db.list_resources()
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "agents": agents,
        "resources": resources,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M"),
    })


@app.post("/chat")
async def chat(req: ChatRequest):
    agent = get_agent(req.agent)
    system_prompt = agent.get("system_prompt", "")
    model = agent.get("model", "llama3.1:latest")
    reply = await handle_message(
        phone=req.phone,
        text=req.message,
        channel=req.channel,
        system_prompt=system_prompt,
        model=model,
    )
    return {"reply": reply, "phone": req.phone}


# ── Telegram ──────────────────────────────────────────────────────────────────

@app.post("/webhook/telegram")
async def telegram_webhook(request: Request):
    data = await request.json()
    msg = data.get("message", {})
    chat_obj = msg.get("chat", {})
    text = msg.get("text", "")
    phone = str(chat_obj.get("id", ""))
    if not phone or not text:
        return {"ok": True}

    agent = get_agent()
    reply = await handle_message(
        phone=phone,
        text=text,
        channel="telegram",
        system_prompt=agent.get("system_prompt", ""),
        model=agent.get("model", "llama3.1:latest"),
    )

    bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "")
    if bot_token:
        import httpx
        async with httpx.AsyncClient() as client:
            await client.post(
                f"https://api.telegram.org/bot{bot_token}/sendMessage",
                json={"chat_id": phone, "text": reply, "parse_mode": "Markdown"},
            )
    return {"ok": True}


# ── WhatsApp ──────────────────────────────────────────────────────────────────

@app.post("/webhook/whatsapp")
async def whatsapp_webhook(request: Request):
    data = await request.json()
    try:
        value = data["entry"][0]["changes"][0]["value"]
        
        # 1. Ignore status updates (Read/Delivered)
        if "messages" not in value:
            return {"ok": True}
            
        msg = value["messages"][0]
        phone = msg["from"]
        text = msg["text"]["body"]

        # 2. Prevent the Maruti Bot Feedback Loop
        bot_keywords = ["employee code", "ARENA/NEXA", "AM02691", "list above"]
        if any(key.lower() in text.lower() for key in bot_keywords):
            return {"ok": True}
            
        # 3. LOG THE MESSAGE (Crucial for context)
        db.save_message(phone, "user", text, "whatsapp")

    except (KeyError, IndexError):
        return {"ok": True}

    # 4. Get Agent & Generate AI Reply
    agent = get_agent()
    reply = await handle_message(
        phone=phone,
        text=text,
        channel="whatsapp",
        system_prompt=agent.get("system_prompt", ""),
        model="llama3.1:latest", 
    )

    # 5. Send to WhatsApp
    token = os.getenv("WHATSAPP_ACCESS_TOKEN", "")
    phone_id = os.getenv("WHATSAPP_PHONE_NUMBER_ID", "")
    
    if token and phone_id:
        import httpx
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"https://graph.facebook.com/v18.0/{phone_id}/messages",
                headers={"Authorization": f"Bearer {token}"},
                json={
                    "messaging_product": "whatsapp",
                    "to": phone,
                    "type": "text",
                    "text": {"body": reply},
                },
            )
            # Log the outgoing message too
            if response.status_code == 200:
                db.save_message(phone, "assistant", reply, "whatsapp")
                
    return {"ok": True}

# ── Conversations ─────────────────────────────────────────────────────────────

@app.get("/conversations")
async def list_conversations():
    conn = db.get_conn()
    rows = conn.execute("""
        SELECT m.phone, c.name, c.channel, MAX(m.timestamp) as last_msg,
               COUNT(m.id) as msg_count
        FROM messages m
        LEFT JOIN customers c ON c.phone = m.phone
        GROUP BY m.phone
        ORDER BY last_msg DESC
        LIMIT 100
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.get("/conversations/{phone}")
async def get_conversation(phone: str):
    history = db.get_history(phone, limit=100)
    return {"phone": phone, "messages": history}


# ── Agent management ──────────────────────────────────────────────────────────

@app.post("/agent/create")
async def create_agent(req: AgentCreateRequest):
    agents = load_agents()
    if req.description and not req.system_prompt:
        from app.ollama_client import generate_agent_prompt
        req.system_prompt = await generate_agent_prompt(req.description, req.model)

    agents[req.name] = {
        "name": req.name,
        "language": req.language,
        "model": req.model,
        "system_prompt": req.system_prompt,
        "channels": req.channels,
    }
    with open(AGENT_CONFIG_PATH, "w") as f:
        json.dump(agents, f, indent=2, ensure_ascii=False)
    return {"success": True, "agent": req.name}


@app.get("/agent/list")
async def list_agents():
    agents = load_agents()
    return list(agents.values())


# ── Resources / Knowledge Base ────────────────────────────────────────────────

@app.post("/resources/upload")
async def upload_resource(
    file: UploadFile = File(...),
    description: str = Form(default=""),
):
    file_bytes = await file.read()
    result = process_and_save_resource(file.filename, file_bytes, description)
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result.get("error", "Upload failed"))
    return result


@app.get("/resources/list")
async def list_resources_endpoint():
    return db.list_resources()


@app.delete("/resources/{resource_id}")
async def delete_resource(resource_id: int):
    db.delete_resource(resource_id)
    return {"success": True}


# ── Incentive API ─────────────────────────────────────────────────────────────

@app.get("/incentive/search")
async def incentive_search(q: str = Query(..., description="Name or emp code to search")):
    results = search_by_name(q)
    return {"results": results, "count": len(results)}


@app.get("/incentive/employee/{emp_code}")
async def incentive_employee(emp_code: str, months: int = Query(default=1)):
    emp = search_by_emp_code(emp_code)
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    if months == 1:
        data = current_month_incentive(emp_code)
    else:
        data = last_n_months_incentive(emp_code, months)
    return {"employee": emp, "incentive": data}

@app.api_route("/call/voice", methods=["GET", "POST"])
async def call_voice():
    """Initial Twilio Greeting"""
    return Response(
        content=f"""
        <Response>
            <Say>Hello, this is Sara from AM Motors.</Say>
            <Gather input="speech" action="{BASE_URL}/call/process" method="POST" language="en-IN">
                <Say>Please tell me your requirement.</Say>
            </Gather>
        </Response>
        """,
        media_type="application/xml"
    )

@app.api_route("/call/process", methods=["GET", "POST"])
async def process_call(request: Request):
    """Processes Speech with Ollama"""
    try:
        form = await request.form()
        user_text = form.get("SpeechResult", "")
        phone = form.get("From", "voice_user")

        if not user_text:
            reply = "Sorry, I didn't catch that. Could you please repeat?"
        else:
            # 1. Get History
            raw_history = db.get_history(phone, limit=5)
            
            # 2. Format history strictly for Ollama (role/content only)
            formatted_messages = []
            for h in raw_history:
                role = "assistant" if h.get("role") == "assistant" else "user"
                formatted_messages.append({"role": role, "content": h.get("content", "")})
            
            # Add current user message
            formatted_messages.append({"role": "user", "content": user_text})

            system_prompt = "You are Sara from AM Motors. Speak only in English. Keep responses short. Be friendly."

            # 3. Call Ollama using the aliased function
            reply = await ollama_chat(
                messages=formatted_messages,
                system=system_prompt,
                model="llama3.1:latest"
            )

            # 4. Save to DB
            db.save_message(phone, "user", user_text, "voice")
            db.save_message(phone, "assistant", reply, "voice")

        return Response(
            content=f"""
            <Response>
                <Say>{reply}</Say>
                <Gather input="speech" action="{BASE_URL}/call/process" method="POST" language="en-IN">
                    <Say>Is there anything else I can help you with?</Say>
                </Gather>
            </Response>
            """,
            media_type="application/xml"
        )

    except Exception as e:
        print("CRITICAL VOICE ERROR:")
        traceback.print_exc()  # Check your terminal logs for the specific error!
        return Response(
            content="""
            <Response>
                <Say>I am having trouble connecting to my brain right now. Please try again later.</Say>
            </Response>
            """,
            media_type="application/xml"
        )