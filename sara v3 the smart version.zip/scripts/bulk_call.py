"""
bulk_call.py — Bulk caller using Exotel + employee incentive data.

Usage:
  python scripts/bulk_call.py --file calls.xlsx --mode whatsapp --limit 10
  python scripts/bulk_call.py --file calls.xlsx --mode voice --limit 5
"""
from urllib.parse import quote
import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

import openpyxl
import httpx
from dotenv import load_dotenv

load_dotenv()

BASE_URL = "https://unrhetorically-unbrazen-earl.ngrok-free.dev"
"""EXOTEL_SID = os.getenv("EXOTEL_SID", "")
EXOTEL_TOKEN = os.getenv("EXOTEL_TOKEN", "")
EXOTEL_FROM = os.getenv("EXOTEL_FROM_NUMBER", "")"""
TWILIO_SID    = os.getenv("TWILIO_SID","")
TWILIO_TOKEN  = os.getenv("TWILIO_TOKEN","")
TWILIO_FROM   = os.getenv("TWILIO_FROM","")


def load_call_list(filepath: str) -> list[dict]:
    wb = openpyxl.load_workbook(filepath, read_only=True, data_only=True)
    ws = wb.active
    headers = [str(c).strip().lower() for c in next(ws.iter_rows(max_row=1, values_only=True))]
    rows = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        rec = dict(zip(headers, row))
        if rec.get("phone"):
            rows.append(rec)
    wb.close()
    return rows


async def send_whatsapp(phone: str, message: str):
    async with httpx.AsyncClient() as client:
        r = await client.post(f"{BASE_URL}/chat", json={
            "phone": phone,
            "message": message,
            "channel": "whatsapp",
        })
        return r.json()


from twilio.rest import Client

async def make_twilio_call(phone: str, message: str):
    if not all([TWILIO_SID, TWILIO_TOKEN, TWILIO_FROM]):
        print(f"[SKIP] Twilio not configured for {phone}")
        return

    client = Client(TWILIO_SID, TWILIO_TOKEN)

    encoded_msg = quote(message)

    call = client.calls.create(
        to="+91" + phone,  # ensure proper format
        from_=TWILIO_FROM,
        url=f"{BASE_URL}/call/voice?msg={encoded_msg}"
    )

    return call.sid


async def run_bulk(filepath: str, mode: str, limit: int, message_template: str):
    records = load_call_list(filepath)[:limit]
    print(f"Processing {len(records)} records via {mode}...")

    for i, rec in enumerate(records, 1):
        phone = str(rec.get("phone", "")).strip()
        name = str(rec.get("name", "")).strip()
        notes = str(rec.get("notes", "")).strip()

        msg = message_template.format(name=name, notes=notes)
        print(f"[{i}/{len(records)}] {phone} ({name})")

        if mode == "whatsapp":
            result = await send_whatsapp(phone, msg)
            print(f"  → {result.get('reply', 'sent')[:80]}")
        elif mode == "voice":
            result = await make_twilio_call(phone, msg)
            print(f"  → Call initiated: {result}")

        await asyncio.sleep(1)  # Rate limiting


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Sara Bulk Caller")
    parser.add_argument("--file", required=True, help="Excel file with phone, name, notes columns")
    parser.add_argument("--mode", choices=["whatsapp", "voice"], default="whatsapp")
    parser.add_argument("--limit", type=int, default=10)
    parser.add_argument("--message", default="Hello {name}! This is Sara from AM Motors. {notes}")
    args = parser.parse_args()

    asyncio.run(run_bulk(args.file, args.mode, args.limit, args.message))
