"""
resource_manager.py — Advanced Knowledge Base for Sara.

Features:
  - Smart text chunking (overlap windows)
  - TF-IDF keyword scoring for accurate retrieval
  - Table-aware extraction (Excel/CSV)
  - Image OCR with pytesseract
  - PowerBI .pbix metadata extraction
  - Physical file deletion on resource removal
"""

import io
import os
import re
import math
import json
import traceback
from pathlib import Path
from typing import Optional
from collections import Counter
import pytesseract
RESOURCES_DIR = os.getenv("RESOURCES_DIR", "resources")
os.makedirs(RESOURCES_DIR, exist_ok=True)

CHUNK_SIZE = 800      # characters per chunk
CHUNK_OVERLAP = 200   # overlap between chunks
MAX_CHUNKS_PER_FILE = 50

pytesseract.pytesseract.tesseract_cmd = r"D:\ocr\tesseract.exe"
# ── Text Extraction ───────────────────────────────────────────────────────────

def _extract_pdf(file_bytes: bytes) -> str:
    try:
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(file_bytes))
        texts = []
        for i, page in enumerate(reader.pages):
            t = page.extract_text()
            if t:
                texts.append(f"[Page {i+1}]\n{t}")
        return "\n\n".join(texts)
    except Exception as e:
        return f"[PDF extraction error: {e}]"


def _extract_csv(file_bytes: bytes) -> str:
    try:
        import pandas as pd
        df = pd.read_csv(io.BytesIO(file_bytes))
        # Also include column stats
        parts = [df.to_string(index=False)]
        numeric_cols = df.select_dtypes(include='number').columns.tolist()
        if numeric_cols:
            parts.append("\n[Summary Statistics]")
            parts.append(df[numeric_cols].describe().to_string())
        return "\n\n".join(parts)
    except Exception as e:
        return f"[CSV extraction error: {e}]"


def _extract_xlsx(file_bytes: bytes) -> str:
    try:
        import pandas as pd
        xl = pd.ExcelFile(io.BytesIO(file_bytes))
        parts = []
        for sheet in xl.sheet_names:
            df = xl.parse(sheet)
            if df.empty:
                continue
            # Drop fully empty rows/cols
            df = df.dropna(how='all').dropna(axis=1, how='all')
            text = df.to_string(index=False)
            # Add numeric summaries
            numeric_cols = df.select_dtypes(include='number').columns.tolist()
            summary = ""
            if numeric_cols:
                desc = df[numeric_cols].describe()
                summary = f"\n[{sheet} Stats]\n{desc.to_string()}"
            parts.append(f"=== Sheet: {sheet} ===\n{text}{summary}")
        return "\n\n".join(parts)
    except Exception as e:
        return f"[Excel extraction error: {e}]"


def _extract_image(file_bytes: bytes) -> str:
    try:
        import pytesseract
        from PIL import Image
        img = Image.open(io.BytesIO(file_bytes))
        # Try multiple languages including Malayalam
        text = pytesseract.image_to_string(img, lang='eng+mal') 
        if not text.strip():
            text = pytesseract.image_to_string(img)
        return text
    except ImportError:
        return "[Image OCR not available — install pytesseract and pillow]"
    except Exception as e:
        return f"[Image extraction error: {e}]"


def _extract_pbix(file_bytes: bytes) -> str:
    """Extract metadata from PowerBI .pbix files (ZIP-based format)."""
    try:
        import zipfile
        result_parts = ["[PowerBI Report File]\n"]
        with zipfile.ZipFile(io.BytesIO(file_bytes)) as zf:
            names = zf.namelist()
            result_parts.append(f"Files in package: {', '.join(names[:20])}\n")
            
            # Try to read DataModel or Report metadata
            metadata_files = ['Report/Layout', 'Metadata', 'DataModel']
            for mf in metadata_files:
                if mf in names:
                    try:
                        raw = zf.read(mf)
                        text = raw.decode('utf-8', errors='replace')[:5000]
                        result_parts.append(f"\n[{mf}]\n{text}")
                    except Exception:
                        pass
            
            # Try reading connections
            if 'Connections' in names:
                try:
                    raw = zf.read('Connections')
                    conn_data = json.loads(raw.decode('utf-8', errors='replace'))
                    result_parts.append(f"\n[Connections]\n{json.dumps(conn_data, indent=2)[:2000]}")
                except Exception:
                    pass
                    
        return "\n".join(result_parts)
    except Exception as e:
        return f"[PowerBI extraction error: {e}]"


def extract_text(filename: str, file_bytes: bytes) -> tuple[str, str]:
    """Returns (file_type, extracted_text)."""
    ext = Path(filename).suffix.lower()
    
    if ext == ".pdf":
        return "pdf", _extract_pdf(file_bytes)
    elif ext == ".csv":
        return "csv", _extract_csv(file_bytes)
    elif ext in (".xlsx", ".xlsm", ".xls"):
        return "excel", _extract_xlsx(file_bytes)
    elif ext in (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tiff"):
        return "image", _extract_image(file_bytes)
    elif ext == ".pbix":
        return "powerbi", _extract_pbix(file_bytes)
    elif ext in (".txt", ".md", ".log", ".rst", ".html", ".json"):
        return "text", file_bytes.decode("utf-8", errors="replace")
    else:
        try:
            return "text", file_bytes.decode("utf-8", errors="replace")
        except Exception:
            return "binary", "[Cannot extract text from this file type]"


# ── Smart Chunking ────────────────────────────────────────────────────────────

def _chunk_text(text: str, filename: str) -> list[dict]:
    """
    Split text into overlapping chunks for better retrieval.
    Returns list of {chunk_index, text, tokens}.
    """
    # Split by natural boundaries first
    paragraphs = re.split(r'\n{2,}|\[Page \d+\]', text)
    
    chunks = []
    current_chunk = ""
    chunk_idx = 0
    
    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
            
        if len(current_chunk) + len(para) < CHUNK_SIZE:
            current_chunk += "\n\n" + para if current_chunk else para
        else:
            if current_chunk:
                chunks.append({
                    "chunk_index": chunk_idx,
                    "text": current_chunk,
                    "source": filename,
                })
                chunk_idx += 1
                # Keep overlap
                overlap_start = max(0, len(current_chunk) - CHUNK_OVERLAP)
                current_chunk = current_chunk[overlap_start:] + "\n\n" + para
            else:
                # Paragraph is too big, force split
                for i in range(0, len(para), CHUNK_SIZE - CHUNK_OVERLAP):
                    chunk = para[i:i + CHUNK_SIZE]
                    if chunk:
                        chunks.append({
                            "chunk_index": chunk_idx,
                            "text": chunk,
                            "source": filename,
                        })
                        chunk_idx += 1
                current_chunk = ""
                
            if chunk_idx >= MAX_CHUNKS_PER_FILE:
                break
    
    if current_chunk and chunk_idx < MAX_CHUNKS_PER_FILE:
        chunks.append({
            "chunk_index": chunk_idx,
            "text": current_chunk,
            "source": filename,
        })
    
    return chunks if chunks else [{"chunk_index": 0, "text": text[:CHUNK_SIZE * 5], "source": filename}]


# ── TF-IDF Retrieval ──────────────────────────────────────────────────────────

def _tokenize(text: str) -> list[str]:
    """Simple tokenizer: lowercase, split on non-alphanumeric."""
    return re.findall(r'\b[a-z0-9₹]{2,}\b', text.lower())


def _tfidf_score(query: str, document: str, corpus: list[str]) -> float:
    """Compute TF-IDF score for a document against a query."""
    query_tokens = set(_tokenize(query))
    doc_tokens = _tokenize(document)
    doc_counter = Counter(doc_tokens)
    doc_len = len(doc_tokens)
    
    if doc_len == 0:
        return 0.0
    
    score = 0.0
    for token in query_tokens:
        tf = doc_counter.get(token, 0) / doc_len
        # Count how many docs contain this token
        df = sum(1 for d in corpus if token in d.lower())
        idf = math.log((len(corpus) + 1) / (df + 1)) + 1
        score += tf * idf
    
    return score


def search_resources_smart(query: str, top_k: int = 5) -> list[dict]:
    """
    Smart TF-IDF search over chunked resource content.
    Returns ranked chunks with scores.
    """
    from app.db import get_all_resource_chunks
    chunks = get_all_resource_chunks()
    
    if not chunks:
        # Fallback to simple search
        from app.db import search_resources
        return search_resources(query)
    
    # Build corpus for IDF
    corpus = [c["content"] for c in chunks]
    
    # Score each chunk
    scored = []
    for chunk in chunks:
        score = _tfidf_score(query, chunk["content"], corpus)
        if score > 0:
            scored.append({
                "id": chunk["resource_id"],
                "filename": chunk["filename"],
                "file_type": chunk["file_type"],
                "chunk_index": chunk["chunk_index"],
                "snippet": chunk["content"],
                "score": score,
            })
    
    # Sort by score descending
    scored.sort(key=lambda x: x["score"], reverse=True)
    
    # Deduplicate by filename (keep best chunk per file first, then allow more)
    seen_files = {}
    results = []
    for item in scored:
        fname = item["filename"]
        if fname not in seen_files:
            seen_files[fname] = 0
        if seen_files[fname] < 2:  # allow up to 2 chunks per file
            seen_files[fname] += 1
            results.append(item)
        if len(results) >= top_k:
            break
    
    return results


# ── Process & Save ────────────────────────────────────────────────────────────

def process_and_save_resource(filename: str, file_bytes: bytes, description: str = "") -> dict:
    """Extract text, chunk it, and save to DB."""
    from app.db import save_resource, save_resource_chunks
    
    file_type, content = extract_text(filename, file_bytes)
    
    if not content.strip() or content.startswith("[") and "error" in content.lower():
        return {"success": False, "error": f"Could not extract text: {content[:200]}"}
    
    # Save physical file
    save_path = os.path.join(RESOURCES_DIR, filename)
    with open(save_path, "wb") as f:
        f.write(file_bytes)
    
    # Save full content to resources table
    resource_id = save_resource(filename, file_type, content, description)
    
    # Chunk and save to chunks table for better search
    chunks = _chunk_text(content, filename)
    save_resource_chunks(resource_id, chunks)
    
    return {
        "success": True,
        "filename": filename,
        "file_type": file_type,
        "chars_indexed": len(content),
        "chunks_created": len(chunks),
    }


def delete_resource_file(filename: str):
    """Delete the physical file from the resources directory."""
    save_path = os.path.join(RESOURCES_DIR, filename)
    if os.path.exists(save_path):
        os.remove(save_path)


def answer_from_resources(question: str, top_k: int = 5) -> Optional[str]:
    """
    Search resources and return best matching context for the LLM.
    Returns None if nothing found.
    """
    results = search_resources_smart(question, top_k=top_k)
    
    if not results:
        return None
    
    # Build context string with source attribution
    parts = []
    seen_files = set()
    for r in results:
        fname = r.get("filename", "Unknown")
        snippet = r.get("snippet", r.get("content", ""))[:1000]
        
        if fname not in seen_files:
            parts.append(f"📄 Source: {fname}")
            seen_files.add(fname)
        
        parts.append(snippet.strip())
        parts.append("---")
    
    if not parts:
        return None
    
    context = f"Relevant information from knowledge base ({len(results)} sections found):\n\n" + "\n".join(parts)
    return context
