"""
incentive_engine.py — Reads the Sales Managers Excel and answers incentive queries.

Column map (0-indexed after the leading None col):
  0  → ignored (None)
  1  → Sl No
  2  → Branch
  3  → Emp Code
  4  → Name
  5  → Designation
  6  → Dealer
  7  → Target
  8  → Achieved
  9  → Total Retail
  10 → Net Incentive
  11 → MSIL Scheme
  12 → Salary
  13 → Take Home
  14 → MM-yyyy (datetime)
  15 → Month  (str e.g. 'Apr')
  16 → Year   (str e.g. '2019-20')
  17 → Channel (ARENA / NEXA)
"""

import os
import re
from datetime import datetime, timedelta
from functools import lru_cache
from typing import Optional

import openpyxl

EXCEL_PATH = os.getenv(
    "INCENTIVE_EXCEL",
    "Sales Managers Take Home Analysis (Same month MF + MSIL Scheme).xlsx",
)

MONTH_ORDER = {
    "Apr": 1, "May": 2, "Jun": 3, "Jul": 4,
    "Aug": 5, "Sep": 6, "Oct": 7, "Nov": 8,
    "Dec": 9, "Jan": 10, "Feb": 11, "Mar": 12,
}


# ── Load data ────────────────────────────────────────────────────────────────

@lru_cache(maxsize=1)
def _load_records() -> list[dict]:
    wb = openpyxl.load_workbook(EXCEL_PATH, read_only=True, data_only=True)
    ws = wb["Managers"]
    records = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if row[4] is None:          # skip empty name rows
            continue
        try:
            net_incentive = float(row[10]) if row[10] is not None else 0.0
            msil_scheme   = float(row[11]) if row[11] is not None else 0.0
            salary        = float(row[12]) if row[12] is not None else 0.0
            # Take home can be a formula string in non-data_only mode; compute it
            take_home_raw = row[13]
            if isinstance(take_home_raw, (int, float)):
                take_home = float(take_home_raw)
            else:
                take_home = salary + net_incentive + msil_scheme

            records.append({
                "branch":        str(row[2]).strip() if row[2] else "",
                "emp_code":      str(row[3]).strip() if row[3] else "",
                "name":          str(row[4]).strip() if row[4] else "",
                "designation":   str(row[5]).strip() if row[5] else "",
                "dealer":        str(row[6]).strip() if row[6] else "",
                "target":        float(row[7]) if row[7] else 0,
                "achieved":      float(row[8]) if row[8] else 0,
                "total_retail":  float(row[9]) if row[9] else 0,
                "net_incentive": net_incentive,
                "msil_scheme":   msil_scheme,
                "salary":        salary,
                "take_home":     take_home,
                "date":          row[14] if isinstance(row[14], datetime) else None,
                "month":         str(row[15]).strip() if row[15] else "",
                "year":          str(row[16]).strip() if row[16] else "",
                "channel":       str(row[17]).strip() if row[17] else "",
            })
        except Exception:
            continue
    wb.close()
    return records


def reload_excel(path: str):
    """Call when Excel is replaced."""
    global EXCEL_PATH
    EXCEL_PATH = path
    _load_records.cache_clear()


# ── Search helpers ────────────────────────────────────────────────────────────

def search_by_name(query: str) -> list[dict]:
    """Return distinct employees (by emp_code) whose name contains `query`."""
    query_lower = query.lower().strip()
    records = _load_records()
    seen = {}
    for r in records:
        if query_lower in r["name"].lower():
            key = r["emp_code"]
            if key not in seen:
                seen[key] = {
                    "emp_code":    r["emp_code"],
                    "name":        r["name"],
                    "branch":      r["branch"],
                    "designation": r["designation"],
                    "channel":     r["channel"],
                }
    return list(seen.values())


def search_by_emp_code(code: str) -> Optional[dict]:
    """Return employee identity dict if found."""
    code_upper = code.upper().strip()
    records = _load_records()
    for r in records:
        if r["emp_code"].upper() == code_upper:
            return {
                "emp_code":    r["emp_code"],
                "name":        r["name"],
                "branch":      r["branch"],
                "designation": r["designation"],
                "channel":     r["channel"],
            }
    return None


# ── Date helpers ──────────────────────────────────────────────────────────────

def _latest_month(emp_code: str) -> Optional[dict]:
    """Return the most recent record for this employee."""
    records = _load_records()
    emp_records = [r for r in records if r["emp_code"].upper() == emp_code.upper()]
    if not emp_records:
        return None
    return max(emp_records, key=lambda r: r["date"] or datetime.min)


def _records_for_employee(emp_code: str) -> list[dict]:
    records = _load_records()
    return [r for r in records if r["emp_code"].upper() == emp_code.upper()]


# ── Incentive calculations ────────────────────────────────────────────────────

def current_month_incentive(emp_code: str) -> dict:
    """Return incentive for the most recent available month."""
    rec = _latest_month(emp_code)
    if not rec:
        return {"error": "Employee not found"}
    return {
        "employee":      rec["name"],
        "emp_code":      rec["emp_code"],
        "branch":        rec["branch"],
        "channel":       rec["channel"],
        "month":         rec["month"],
        "year":          rec["year"],
        "net_incentive": round(rec["net_incentive"], 2),
        "msil_scheme":   round(rec["msil_scheme"], 2),
        "total_incentive": round(rec["net_incentive"] + rec["msil_scheme"], 2),
        "salary":        round(rec["salary"], 2),
        "take_home":     round(rec["take_home"], 2),
        "target":        rec["target"],
        "achieved":      rec["achieved"],
    }


def last_n_months_incentive(emp_code: str, n: int) -> dict:
    """Return incentive summary for the last n months."""
    emp_records = _records_for_employee(emp_code)
    if not emp_records:
        return {"error": "Employee not found"}

    # Sort by date descending, take n
    sorted_records = sorted(
        [r for r in emp_records if r["date"] is not None],
        key=lambda r: r["date"],
        reverse=True,
    )[:n]

    if not sorted_records:
        return {"error": "No records found"}

    total_net    = sum(r["net_incentive"] for r in sorted_records)
    total_msil   = sum(r["msil_scheme"] for r in sorted_records)
    total_salary = sum(r["salary"] for r in sorted_records)
    total_take   = sum(r["take_home"] for r in sorted_records)

    monthly = [
        {
            "month":         r["month"],
            "year":          r["year"],
            "net_incentive": round(r["net_incentive"], 2),
            "msil_scheme":   round(r["msil_scheme"], 2),
            "total_incentive": round(r["net_incentive"] + r["msil_scheme"], 2),
            "salary":        round(r["salary"], 2),
            "take_home":     round(r["take_home"], 2),
        }
        for r in sorted_records
    ]

    return {
        "employee":           sorted_records[0]["name"],
        "emp_code":           emp_code,
        "branch":             sorted_records[0]["branch"],
        "channel":            sorted_records[0]["channel"],
        "months_count":       len(sorted_records),
        "period":             f"{sorted_records[-1]['month']} {sorted_records[-1]['year']} – {sorted_records[0]['month']} {sorted_records[0]['year']}",
        "total_net_incentive": round(total_net, 2),
        "total_msil_scheme":  round(total_msil, 2),
        "total_incentive":    round(total_net + total_msil, 2),
        "avg_incentive":      round((total_net + total_msil) / len(sorted_records), 2),
        "total_salary":       round(total_salary, 2),
        "total_take_home":    round(total_take, 2),
        "monthly_breakdown":  monthly,
    }


def specific_month_incentive(emp_code: str, month: str, year: str) -> dict:
    """Return incentive for a specific month and year string."""
    emp_records = _records_for_employee(emp_code)
    for r in emp_records:
        if r["month"].lower() == month.lower() and r["year"] == year:
            return {
                "employee":       r["name"],
                "emp_code":       r["emp_code"],
                "branch":         r["branch"],
                "channel":        r["channel"],
                "month":          r["month"],
                "year":           r["year"],
                "net_incentive":  round(r["net_incentive"], 2),
                "msil_scheme":    round(r["msil_scheme"], 2),
                "total_incentive": round(r["net_incentive"] + r["msil_scheme"], 2),
                "salary":         round(r["salary"], 2),
                "take_home":      round(r["take_home"], 2),
                "target":         r["target"],
                "achieved":       r["achieved"],
            }
    return {"error": f"No record found for {month} {year}"}


# ── Intent parser ─────────────────────────────────────────────────────────────

def parse_incentive_intent(text: str) -> dict:
    """
    Parse user message to identify incentive query type.
    Returns: {type: 'current'|'last_n'|'specific', months: int, month: str, year: str}
    """
    t = text.lower()

    # last N months
    m = re.search(r"last\s+(\d+)\s+month", t)
    if m:
        return {"type": "last_n", "months": int(m.group(1))}

    # this month / current month
    if any(x in t for x in ["this month", "current month", "ഈ മാസം", "ഇത്തവണ"]):
        return {"type": "current"}

    # "7 month" or "12 month" without "last"
    m = re.search(r"(\d+)\s+month", t)
    if m:
        return {"type": "last_n", "months": int(m.group(1))}

    # specific month name
    month_names = {
        "january": "Jan", "february": "Feb", "march": "Mar",
        "april": "Apr", "may": "May", "june": "Jun",
        "july": "Jul", "august": "Aug", "september": "Sep",
        "october": "Oct", "november": "Nov", "december": "Dec",
        "jan": "Jan", "feb": "Feb", "mar": "Mar", "apr": "Apr",
        "jun": "Jun", "jul": "Jul", "aug": "Aug", "sep": "Sep",
        "oct": "Oct", "nov": "Nov", "dec": "Dec",
    }
    for name, abbr in month_names.items():
        if name in t:
            # Try to find year
            yr_m = re.search(r"20\d{2}", text)
            year = yr_m.group(0) if yr_m else str(datetime.now().year)
            return {"type": "specific", "month": abbr, "year": year}

    # default: current
    return {"type": "current"}


def format_incentive_response(data: dict, intent: dict) -> str:
    """Format incentive data into a clean readable string for the LLM."""
    if "error" in data:
        return f"Sorry, {data['error']}."

    if intent["type"] == "current":
        return (
            f"📊 **Incentive for {data['month']} {data['year']}**\n"
            f"Employee: {data['employee']} ({data['emp_code']})\n"
            f"Branch: {data['branch']} | Channel: {data['channel']}\n"
            f"Net Incentive: ₹{data['net_incentive']:,.2f}\n"
            f"MSIL Scheme: ₹{data['msil_scheme']:,.2f}\n"
            f"Total Incentive: ₹{data['total_incentive']:,.2f}\n"
            f"Salary: ₹{data['salary']:,.2f}\n"
            f"Take Home: ₹{data['take_home']:,.2f}\n"
            f"Target: {int(data['target'])} | Achieved: {int(data['achieved'])}"
        )
    elif intent["type"] == "last_n":
        lines = [
            f"📊 **Last {data['months_count']} Months Incentive Summary**",
            f"Employee: {data['employee']} ({data['emp_code']})",
            f"Branch: {data['branch']} | Channel: {data['channel']}",
            f"Period: {data['period']}",
            f"Total Net Incentive: ₹{data['total_net_incentive']:,.2f}",
            f"Total MSIL Scheme: ₹{data['total_msil_scheme']:,.2f}",
            f"**Total Incentive: ₹{data['total_incentive']:,.2f}**",
            f"Average Monthly Incentive: ₹{data['avg_incentive']:,.2f}",
            f"Total Take Home: ₹{data['total_take_home']:,.2f}",
            "",
            "Monthly Breakdown:",
        ]
        for mb in data["monthly_breakdown"]:
            lines.append(
                f"  {mb['month']} {mb['year']}: ₹{mb['total_incentive']:,.2f} (Salary: ₹{mb['salary']:,.2f}, Take Home: ₹{mb['take_home']:,.2f})"
            )
        return "\n".join(lines)
    else:
        return (
            f"📊 **Incentive for {data['month']} {data['year']}**\n"
            f"Employee: {data['employee']} ({data['emp_code']})\n"
            f"Net Incentive: ₹{data['net_incentive']:,.2f}\n"
            f"MSIL Scheme: ₹{data['msil_scheme']:,.2f}\n"
            f"Total Incentive: ₹{data['total_incentive']:,.2f}\n"
            f"Salary: ₹{data['salary']:,.2f}\n"
            f"Take Home: ₹{data['take_home']:,.2f}"
        )
