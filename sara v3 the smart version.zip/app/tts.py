import os
from gtts import gTTS
from uuid import uuid4

STATIC_DIR = "static/audio"
os.makedirs(STATIC_DIR, exist_ok=True)

def text_to_speech_malayalam(text: str) -> str:
    filename = f"{uuid4()}.mp3"
    filepath = os.path.join(STATIC_DIR, filename)

    tts = gTTS(text=text, lang="ml")
    tts.save(filepath)

    return f"/static/audio/{filename}"