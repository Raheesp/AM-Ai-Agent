"""
ollama_client.py — Local LLM via Ollama HTTP API
"""

import os
import httpx
import json

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
DEFAULT_MODEL = os.getenv("OLLAMA_MODEL", "llama3.1:latest")


async def chat(
    messages: list[dict],
    system: str = "",
    model: str = DEFAULT_MODEL,
    temperature: float = 0.7,
) -> str:
    payload = {
        "model": model,
        "messages": messages,
        "stream": False,
        "options": {"temperature": temperature},
    }
    if system:
        payload["system"] = system

    try:
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(f"{OLLAMA_URL}/api/chat", json=payload)
            resp.raise_for_status()
            data = resp.json()
            return data["message"]["content"]
    except Exception as e:
        return f"[LLM Error: {e}]"


async def generate_agent_prompt(description: str, model: str = DEFAULT_MODEL) -> str:
    """Generate a system prompt from a plain-text agent description."""
    meta_prompt = (
        "You are a prompt engineer. The user describes an AI assistant. "
        "Write a detailed system prompt (300-500 words) for that assistant. "
        "Output ONLY the system prompt, no explanation."
    )
    messages = [{"role": "user", "content": description}]
    return await chat(messages, system=meta_prompt, model=model)
