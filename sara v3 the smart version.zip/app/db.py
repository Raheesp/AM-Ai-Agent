"""
db.py — SQLite database layer for Sara
Handles customers, messages, call_logs, resource knowledge base with chunking,
agent configs, and employee sessions.
"""

import sqlite3
import os
import json
from datetime import datetime

DB_PATH = os.getenv("DB_PATH", "sara.db")


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.executescript("""
    CREATE TABLE IF NOT EXISTS customers (
        phone          TEXT PRIMARY KEY,
        name           TEXT DEFAULT '',
        channel        TEXT DEFAULT 'api',
        preferred_lang TEXT DEFAULT 'Malayalam',
        created_at     TEXT DEFAULT (datetime('now')),
        updated_at     TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS messages (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        phone     TEXT NOT NULL,
        role      TEXT NOT NULL,
        content   TEXT NOT NULL,
        channel   TEXT DEFAULT 'api',
        timestamp TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS call_logs (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        phone        TEXT NOT NULL,
        status       TEXT,
        duration_sec INTEGER DEFAULT 0,
        summary      TEXT DEFAULT '',
        called_at    TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS resources (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        filename    TEXT NOT NULL,
        file_type   TEXT NOT NULL,
        content     TEXT NOT NULL,
        description TEXT DEFAULT '',
        uploaded_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS resource_chunks (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        resource_id INTEGER NOT NULL,
        chunk_index INTEGER NOT NULL,
        content     TEXT NOT NULL,
        FOREIGN KEY (resource_id) REFERENCES resources(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS agents (
        name           TEXT PRIMARY KEY,
        language       TEXT DEFAULT 'Malayalam',
        model          TEXT DEFAULT 'llama3.1:latest',
        system_prompt  TEXT DEFAULT '',
        description    TEXT DEFAULT '',
        channels       TEXT DEFAULT '["whatsapp","telegram","api"]',
        avatar         TEXT DEFAULT '',
        is_active      INTEGER DEFAULT 1,
        created_at     TEXT DEFAULT (datetime('now')),
        updated_at     TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS employee_sessions (
        phone          TEXT PRIMARY KEY,
        state          TEXT DEFAULT 'idle',
        search_query   TEXT DEFAULT '',
        candidates     TEXT DEFAULT '[]',
        selected_emp   TEXT DEFAULT '',
        last_updated   TEXT DEFAULT (datetime('now'))
    );
    """)

    # Enable WAL mode for better concurrency
    c.execute("PRAGMA journal_mode=WAL")
    # Enable foreign keys
    c.execute("PRAGMA foreign_keys=ON")

    conn.commit()
    conn.close()


# ── Messages ──────────────────────────────────────────────────────────────────

def save_message(phone: str, role: str, content: str, channel: str = "api"):
    conn = get_conn()
    conn.execute(
        "INSERT INTO messages (phone, role, content, channel) VALUES (?, ?, ?, ?)",
        (phone, role, content, channel),
    )
    conn.commit()
    conn.close()


def get_history(phone: str, limit: int = 20) -> list[dict]:
    conn = get_conn()
    rows = conn.execute(
        "SELECT role, content FROM messages WHERE phone=? ORDER BY id DESC LIMIT ?",
        (phone, limit),
    ).fetchall()
    conn.close()
    return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]


# ── Customers ─────────────────────────────────────────────────────────────────

def upsert_customer(phone: str, name: str = "", channel: str = "api", lang: str = "Malayalam"):
    conn = get_conn()
    conn.execute("""
        INSERT INTO customers (phone, name, channel, preferred_lang)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(phone) DO UPDATE SET
            name = CASE WHEN excluded.name != '' THEN excluded.name ELSE name END,
            channel = excluded.channel,
            updated_at = datetime('now')
    """, (phone, name, channel, lang))
    conn.commit()
    conn.close()


# ── Resources ─────────────────────────────────────────────────────────────────

def save_resource(filename: str, file_type: str, content: str, description: str = "") -> int:
    """Save resource and return its ID."""
    conn = get_conn()
    # Delete old resource with same filename + its chunks (CASCADE handles chunks)
    conn.execute("DELETE FROM resources WHERE filename = ?", (filename,))
    cursor = conn.execute(
        "INSERT INTO resources (filename, file_type, content, description) VALUES (?, ?, ?, ?)",
        (filename, file_type, content, description),
    )
    resource_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return resource_id


def save_resource_chunks(resource_id: int, chunks: list[dict]):
    """Save text chunks for a resource."""
    conn = get_conn()
    # Remove old chunks for this resource
    conn.execute("DELETE FROM resource_chunks WHERE resource_id = ?", (resource_id,))
    for chunk in chunks:
        conn.execute(
            "INSERT INTO resource_chunks (resource_id, chunk_index, content) VALUES (?, ?, ?)",
            (resource_id, chunk["chunk_index"], chunk["text"]),
        )
    conn.commit()
    conn.close()


def get_all_resource_chunks() -> list[dict]:
    """Return all chunks joined with resource metadata."""
    conn = get_conn()
    rows = conn.execute("""
        SELECT rc.id, rc.resource_id, rc.chunk_index, rc.content,
               r.filename, r.file_type
        FROM resource_chunks rc
        JOIN resources r ON r.id = rc.resource_id
        ORDER BY rc.resource_id, rc.chunk_index
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def list_resources() -> list[dict]:
    conn = get_conn()
    rows = conn.execute("""
        SELECT r.id, r.filename, r.file_type, r.description, r.uploaded_at,
               COUNT(rc.id) as chunk_count,
               LENGTH(r.content) as char_count
        FROM resources r
        LEFT JOIN resource_chunks rc ON rc.resource_id = r.id
        GROUP BY r.id
        ORDER BY r.uploaded_at DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_resource_content(resource_id: int) -> str | None:
    conn = get_conn()
    row = conn.execute("SELECT content FROM resources WHERE id=?", (resource_id,)).fetchone()
    conn.close()
    return row["content"] if row else None


def get_resource_filename(resource_id: int) -> str | None:
    conn = get_conn()
    row = conn.execute("SELECT filename FROM resources WHERE id=?", (resource_id,)).fetchone()
    conn.close()
    return row["filename"] if row else None


def search_resources(query: str) -> list[dict]:
    """Fallback simple keyword search across all resource chunks."""
    conn = get_conn()
    rows = conn.execute("""
        SELECT rc.content, r.filename, r.file_type, r.id as resource_id
        FROM resource_chunks rc
        JOIN resources r ON r.id = rc.resource_id
    """).fetchall()
    conn.close()
    query_lower = query.lower()
    results = []
    for r in rows:
        if query_lower in r["content"].lower():
            idx = r["content"].lower().find(query_lower)
            snippet = r["content"][max(0, idx - 150): idx + 600]
            results.append({
                "id": r["resource_id"],
                "filename": r["filename"],
                "file_type": r["file_type"],
                "snippet": snippet,
                "score": 1.0,
            })
    return results[:5]


def delete_resource(resource_id: int) -> str | None:
    """Delete resource and its chunks. Returns filename for physical file deletion."""
    filename = get_resource_filename(resource_id)
    conn = get_conn()
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("DELETE FROM resources WHERE id=?", (resource_id,))
    conn.commit()
    conn.close()
    return filename


# ── Agents ────────────────────────────────────────────────────────────────────

def save_agent(name: str, language: str, model: str, system_prompt: str,
               description: str = "", channels: list = None,
               avatar: str = "", is_active: bool = True):
    conn = get_conn()
    conn.execute("""
        INSERT INTO agents (name, language, model, system_prompt, description, channels, avatar, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(name) DO UPDATE SET
            language=excluded.language,
            model=excluded.model,
            system_prompt=excluded.system_prompt,
            description=excluded.description,
            channels=excluded.channels,
            avatar=excluded.avatar,
            is_active=excluded.is_active,
            updated_at=datetime('now')
    """, (name, language, model, system_prompt, description,
          json.dumps(channels or ["whatsapp", "telegram", "api"]),
          avatar, 1 if is_active else 0))
    conn.commit()
    conn.close()


def list_agents() -> list[dict]:
    conn = get_conn()
    rows = conn.execute("SELECT * FROM agents ORDER BY is_active DESC, created_at ASC").fetchall()
    conn.close()
    result = []
    for r in rows:
        d = dict(r)
        try:
            d["channels"] = json.loads(d["channels"])
        except Exception:
            d["channels"] = []
        result.append(d)
    return result


def get_agent(name: str) -> dict | None:
    conn = get_conn()
    row = conn.execute("SELECT * FROM agents WHERE name=?", (name,)).fetchone()
    conn.close()
    if row:
        d = dict(row)
        try:
            d["channels"] = json.loads(d["channels"])
        except Exception:
            d["channels"] = []
        return d
    return None


def get_active_agent() -> dict | None:
    """Get first active agent, or any agent."""
    conn = get_conn()
    row = conn.execute(
        "SELECT * FROM agents WHERE is_active=1 ORDER BY updated_at DESC LIMIT 1"
    ).fetchone()
    conn.close()
    if row:
        d = dict(row)
        try:
            d["channels"] = json.loads(d["channels"])
        except Exception:
            d["channels"] = []
        return d
    return None


def delete_agent(name: str):
    conn = get_conn()
    conn.execute("DELETE FROM agents WHERE name=?", (name,))
    conn.commit()
    conn.close()


def set_active_agent(name: str):
    """Set one agent as active, deactivate others."""
    conn = get_conn()
    conn.execute("UPDATE agents SET is_active=0")
    conn.execute("UPDATE agents SET is_active=1 WHERE name=?", (name,))
    conn.commit()
    conn.close()


# ── Employee Sessions ─────────────────────────────────────────────────────────

def get_emp_session(phone: str) -> dict:
    conn = get_conn()
    row = conn.execute(
        "SELECT * FROM employee_sessions WHERE phone=?", (phone,)
    ).fetchone()
    conn.close()
    if row:
        return {
            "state": row["state"],
            "search_query": row["search_query"],
            "candidates": json.loads(row["candidates"]),
            "selected_emp": row["selected_emp"],
        }
    return {"state": "idle", "search_query": "", "candidates": [], "selected_emp": ""}


def set_emp_session(phone: str, state: str, search_query: str = "",
                    candidates: list = None, selected_emp: str = ""):
    conn = get_conn()
    conn.execute("""
        INSERT INTO employee_sessions (phone, state, search_query, candidates, selected_emp)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(phone) DO UPDATE SET
            state=excluded.state,
            search_query=excluded.search_query,
            candidates=excluded.candidates,
            selected_emp=excluded.selected_emp,
            last_updated=datetime('now')
    """, (phone, state, search_query, json.dumps(candidates or []), selected_emp))
    conn.commit()
    conn.close()


def clear_emp_session(phone: str):
    conn = get_conn()
    conn.execute("DELETE FROM employee_sessions WHERE phone=?", (phone,))
    conn.commit()
    conn.close()
