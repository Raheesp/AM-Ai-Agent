"""
main.py — Sara FastAPI server v3.0

Routes:
  GET  /                          → Dashboard UI
  POST /chat                      → Universal chat endpoint
  POST /webhook/telegram          → Telegram webhook
  GET  /webhook/whatsapp          → WhatsApp verify
  POST /webhook/whatsapp          → WhatsApp messages
  GET  /conversations             → List all conversations
  GET  /conversations/{phone}     → Conversation history
  DELETE /conversations/{phone}   → Clear conversation
  POST /agent/create              → Save/update agent config
  GET  /agent/list                → List agents
  GET  /agent/{name}              → Get specific agent
  DELETE /agent/{name}            → Delete agent
  POST /agent/{name}/activate     → Set as active agent
  POST /resources/upload          → Upload knowledge-base file
  GET  /resources/list            → List resources
  GET  /resources/{id}/preview    → Preview resource content
  DELETE /resources/{id}          → Delete a resource (DB + disk)
  POST /resources/search          → Search knowledge base
  GET  /incentive/search          → Search employee by name
  GET  /incentive/employee/{code} → Get employee incentive
  GET  /health                    → Health check
"""
import traceback
import json
import os
from datetime import datetime
from pathlib import Path
from fastapi import FastAPI, Request, HTTPException, UploadFile, File, Form, Query, Body
from fastapi.responses import HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()

from app import db
from app.chat_handler import handle_message
from app.incentive_engine import (
    search_by_name, search_by_emp_code,
    current_month_incentive, last_n_months_incentive,
)
from app.resource_manager import process_and_save_resource, delete_resource_file, answer_from_resources
from app.ollama_client import chat as ollama_chat
from app.tts import text_to_speech_malayalam

BASE_URL = os.getenv("BASE_URL", "https://unrhetorically-unbrazen-earl.ngrok-free.dev")
RESOURCES_DIR = os.getenv("RESOURCES_DIR", "resources")

# ── Boot ──────────────────────────────────────────────────────────────────────

db.init_db()
os.makedirs(RESOURCES_DIR, exist_ok=True)

app = FastAPI(title="Sara AI Agent", version="3.0.0")
app.mount("/static", StaticFiles(directory="static"), name="static")

templates_dir = Path("app/templates")
templates_dir.mkdir(parents=True, exist_ok=True)
templates = Jinja2Templates(directory=str(templates_dir))


def get_active_agent_config() -> dict:
    """Get the currently active agent from DB, fallback to file config."""
    agent = db.get_active_agent()
    if agent:
        return agent
    # Fallback: try loading from legacy JSON file
    config_path = os.getenv("AGENT_CONFIG", "agent_config.json")
    if os.path.exists(config_path):
        with open(config_path) as f:
            agents = json.load(f)
        if agents:
            first = list(agents.values())[0]
            # Migrate to DB
            db.save_agent(
                name=first.get("name", "Sara"),
                language=first.get("language", "Malayalam"),
                model=first.get("model", "llama3.1:latest"),
                system_prompt=first.get("system_prompt", ""),
                description=first.get("description", ""),
                channels=first.get("channels", ["whatsapp", "telegram", "api"]),
            )
            return first
    return {"name": "Sara", "model": "llama3.1:latest", "system_prompt": "", "language": "Malayalam"}


# ── Models ────────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    phone: str
    message: str
    channel: str = "api"
    agent: str = ""  # empty = use active agent


class AgentCreateRequest(BaseModel):
    name: str
    language: str = "Malayalam"
    model: str = "llama3.1:latest"
    description: str = ""
    system_prompt: str = ""
    channels: list[str] = ["whatsapp", "telegram", "api"]
    avatar: str = ""
    is_active: bool = False
    auto_generate_prompt: bool = False


# ── Dashboard ─────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    agents = db.list_agents()
    resources = db.list_resources()
    # Get conversation stats
    conn = db.get_conn()
    stats = conn.execute("""
        SELECT 
            COUNT(DISTINCT phone) as total_users,
            COUNT(*) as total_messages,
            SUM(CASE WHEN role='user' THEN 1 ELSE 0 END) as user_messages,
            SUM(CASE WHEN timestamp > datetime('now', '-1 day') THEN 1 ELSE 0 END) as today_messages
        FROM messages
    """).fetchone()
    conn.close()
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "agents": agents,
        "resources": resources,
        "stats": dict(stats) if stats else {},
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M"),
    })


# ── Health ────────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    resources = db.list_resources()
    agents = db.list_agents()
    return {
        "status": "ok",
        "version": "3.0.0",
        "agents": len(agents),
        "resources": len(resources),
        "timestamp": datetime.now().isoformat(),
    }


# ── Chat ──────────────────────────────────────────────────────────────────────

@app.post("/chat")
async def chat(req: ChatRequest):
    if req.agent:
        agent = db.get_agent(req.agent) or get_active_agent_config()
    else:
        agent = get_active_agent_config()
    
    system_prompt = agent.get("system_prompt", "")
    model = agent.get("model", "llama3.1:latest")
    reply = await handle_message(
        phone=req.phone,
        text=req.message,
        channel=req.channel,
        system_prompt=system_prompt,
        model=model,
    )
    return {"reply": reply, "phone": req.phone, "agent": agent.get("name", "Sara")}


# ── Telegram ──────────────────────────────────────────────────────────────────

@app.post("/webhook/telegram")
async def telegram_webhook(request: Request):
    data = await request.json()
    msg = data.get("message", {})
    chat_obj = msg.get("chat", {})
    text = msg.get("text", "")
    phone = str(chat_obj.get("id", ""))
    if not phone or not text:
        return {"ok": True}

    agent = get_active_agent_config()
    reply = await handle_message(
        phone=phone, text=text, channel="telegram",
        system_prompt=agent.get("system_prompt", ""),
        model=agent.get("model", "llama3.1:latest"),
    )

    bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "")
    if bot_token:
        import httpx
        async with httpx.AsyncClient() as client:
            await client.post(
                f"https://api.telegram.org/bot{bot_token}/sendMessage",
                json={"chat_id": phone, "text": reply, "parse_mode": "Markdown"},
            )
    return {"ok": True}


# ── WhatsApp ──────────────────────────────────────────────────────────────────

@app.get("/webhook/whatsapp")
async def whatsapp_verify(request: Request):
    params = dict(request.query_params)
    verify_token = os.getenv("WHATSAPP_VERIFY_TOKEN", "sara_verify_token")
    if params.get("hub.verify_token") == verify_token:
        return Response(content=params.get("hub.challenge", ""), media_type="text/plain")
    raise HTTPException(status_code=403, detail="Invalid verify token")


@app.post("/webhook/whatsapp")
async def whatsapp_webhook(request: Request):
    data = await request.json()
    try:
        value = data["entry"][0]["changes"][0]["value"]
        if "messages" not in value:
            return {"ok": True}
        msg = value["messages"][0]
        phone = msg["from"]
        text = msg["text"]["body"]

        bot_keywords = ["employee code", "ARENA/NEXA", "AM02691", "list above"]
        if any(key.lower() in text.lower() for key in bot_keywords):
            return {"ok": True}

        db.save_message(phone, "user", text, "whatsapp")
    except (KeyError, IndexError):
        return {"ok": True}

    agent = get_active_agent_config()
    reply = await handle_message(
        phone=phone, text=text, channel="whatsapp",
        system_prompt=agent.get("system_prompt", ""),
        model=agent.get("model", "llama3.1:latest"),
    )

    token = os.getenv("WHATSAPP_ACCESS_TOKEN", "")
    phone_id = os.getenv("WHATSAPP_PHONE_NUMBER_ID", "")
    if token and phone_id:
        import httpx
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"https://graph.facebook.com/v18.0/{phone_id}/messages",
                headers={"Authorization": f"Bearer {token}"},
                json={"messaging_product": "whatsapp", "to": phone, "type": "text", "text": {"body": reply}},
            )
            if response.status_code == 200:
                db.save_message(phone, "assistant", reply, "whatsapp")
    return {"ok": True}


# ── Conversations ─────────────────────────────────────────────────────────────

@app.get("/conversations")
async def list_conversations():
    conn = db.get_conn()
    rows = conn.execute("""
        SELECT m.phone, c.name, c.channel, MAX(m.timestamp) as last_msg,
               COUNT(m.id) as msg_count
        FROM messages m
        LEFT JOIN customers c ON c.phone = m.phone
        GROUP BY m.phone
        ORDER BY last_msg DESC
        LIMIT 100
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.get("/conversations/{phone}")
async def get_conversation(phone: str):
    history = db.get_history(phone, limit=100)
    return {"phone": phone, "messages": history}


@app.delete("/conversations/{phone}")
async def delete_conversation(phone: str):
    conn = db.get_conn()
    conn.execute("DELETE FROM messages WHERE phone=?", (phone,))
    conn.execute("DELETE FROM customers WHERE phone=?", (phone,))
    conn.execute("DELETE FROM employee_sessions WHERE phone=?", (phone,))
    conn.commit()
    conn.close()
    return {"success": True, "phone": phone}


# ── Agent Management (Full CRUD) ──────────────────────────────────────────────

@app.post("/agent/create")
async def create_agent(req: AgentCreateRequest):
    system_prompt = req.system_prompt
    if req.auto_generate_prompt and req.description and not system_prompt:
        from app.ollama_client import generate_agent_prompt
        system_prompt = await generate_agent_prompt(req.description, req.model)

    db.save_agent(
        name=req.name,
        language=req.language,
        model=req.model,
        system_prompt=system_prompt,
        description=req.description,
        channels=req.channels,
        avatar=req.avatar,
        is_active=req.is_active,
    )
    return {"success": True, "agent": req.name}


@app.get("/agent/list")
async def list_agents():
    return db.list_agents()


@app.get("/agent/{name}")
async def get_agent(name: str):
    agent = db.get_agent(name)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return agent


@app.put("/agent/{name}")
async def update_agent(name: str, req: AgentCreateRequest):
    existing = db.get_agent(name)
    if not existing:
        raise HTTPException(status_code=404, detail="Agent not found")
    db.save_agent(
        name=name,
        language=req.language,
        model=req.model,
        system_prompt=req.system_prompt,
        description=req.description,
        channels=req.channels,
        avatar=req.avatar,
        is_active=req.is_active,
    )
    return {"success": True, "agent": name}


@app.delete("/agent/{name}")
async def delete_agent(name: str):
    existing = db.get_agent(name)
    if not existing:
        raise HTTPException(status_code=404, detail="Agent not found")
    db.delete_agent(name)
    return {"success": True}


@app.post("/agent/{name}/activate")
async def activate_agent(name: str):
    existing = db.get_agent(name)
    if not existing:
        raise HTTPException(status_code=404, detail="Agent not found")
    db.set_active_agent(name)
    return {"success": True, "active_agent": name}


# ── Resources / Knowledge Base ────────────────────────────────────────────────

@app.post("/resources/upload")
async def upload_resource(
    file: UploadFile = File(...),
    description: str = Form(default=""),
):
    file_bytes = await file.read()
    result = process_and_save_resource(file.filename, file_bytes, description)
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result.get("error", "Upload failed"))
    return result


@app.get("/resources/list")
async def list_resources_endpoint():
    return db.list_resources()


@app.get("/resources/{resource_id}/preview")
async def preview_resource(resource_id: int, chars: int = Query(default=2000)):
    content = db.get_resource_content(resource_id)
    if content is None:
        raise HTTPException(status_code=404, detail="Resource not found")
    return {
        "resource_id": resource_id,
        "preview": content[:chars],
        "total_chars": len(content),
        "truncated": len(content) > chars,
    }


@app.delete("/resources/{resource_id}")
async def delete_resource(resource_id: int):
    """Delete resource from DB AND from disk."""
    filename = db.delete_resource(resource_id)
    if filename:
        delete_resource_file(filename)
        return {"success": True, "deleted_file": filename}
    raise HTTPException(status_code=404, detail="Resource not found")


@app.post("/resources/search")
async def search_resources(query: str = Body(..., embed=True)):
    """Search across the knowledge base."""
    from app.resource_manager import search_resources_smart
    results = search_resources_smart(query, top_k=8)
    return {"query": query, "results": results, "count": len(results)}


# ── Incentive API ─────────────────────────────────────────────────────────────

@app.get("/incentive/search")
async def incentive_search(q: str = Query(..., description="Name or emp code to search")):
    results = search_by_name(q)
    return {"results": results, "count": len(results)}


@app.get("/incentive/employee/{emp_code}")
async def incentive_employee(emp_code: str, months: int = Query(default=1)):
    emp = search_by_emp_code(emp_code)
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    if months == 1:
        data = current_month_incentive(emp_code)
    else:
        data = last_n_months_incentive(emp_code, months)
    return {"employee": emp, "incentive": data}


# ── Voice / Twilio ────────────────────────────────────────────────────────────

@app.api_route("/call/voice", methods=["GET", "POST"])
async def call_voice():
    return Response(
        content=f"""
        <Response>
            <Say>Hello, this is Sara from AM Motors.</Say>
            <Gather input="speech" action="{BASE_URL}/call/process" method="POST" language="en-IN">
                <Say>Please tell me your requirement.</Say>
            </Gather>
        </Response>
        """,
        media_type="application/xml"
    )


@app.api_route("/call/process", methods=["GET", "POST"])
async def process_call(request: Request):
    try:
        form = await request.form()
        user_text = form.get("SpeechResult", "")
        phone = form.get("From", "voice_user")

        if not user_text:
            reply = "Sorry, I didn't catch that. Could you please repeat?"
        else:
            raw_history = db.get_history(phone, limit=5)
            formatted_messages = []
            for h in raw_history:
                role = "assistant" if h.get("role") == "assistant" else "user"
                formatted_messages.append({"role": role, "content": h.get("content", "")})
            formatted_messages.append({"role": "user", "content": user_text})

            system_prompt = "You are Sara from AM Motors. Speak only in English. Keep responses short. Be friendly."
            reply = await ollama_chat(
                messages=formatted_messages,
                system=system_prompt,
                model="llama3.1:latest"
            )
            db.save_message(phone, "user", user_text, "voice")
            db.save_message(phone, "assistant", reply, "voice")

        return Response(
            content=f"""
            <Response>
                <Say>{reply}</Say>
                <Gather input="speech" action="{BASE_URL}/call/process" method="POST" language="en-IN">
                    <Say>Is there anything else I can help you with?</Say>
                </Gather>
            </Response>
            """,
            media_type="application/xml"
        )
    except Exception as e:
        traceback.print_exc()
        return Response(
            content="""
            <Response>
                <Say>I am having trouble connecting right now. Please try again later.</Say>
            </Response>
            """,
            media_type="application/xml"
        )
