"""
WhatsApp Cloud API client (Meta — free tier)
Docs: https://developers.facebook.com/docs/whatsapp/cloud-api
Setup:
  1. Create Meta app at developers.facebook.com
  2. Add WhatsApp product
  3. Get Phone Number ID + Access Token
  4. Set webhook URL to https://yourdomain.com/webhook/whatsapp
  5. Subscribe to 'messages' webhook field
"""

import httpx, os, logging

log = logging.getLogger("sara.whatsapp")

WA_TOKEN     = os.getenv("WHATSAPP_ACCESS_TOKEN", "")
WA_PHONE_ID  = os.getenv("WHATSAPP_PHONE_NUMBER_ID", "")
WA_API_URL   = f"https://graph.facebook.com/v19.0/{WA_PHONE_ID}/messages"


async def send_whatsapp_message(to: str, text: str) -> bool:
    """
    Send a plain text WhatsApp message.
    to = phone in international format without +, e.g. "919876543210"
    """
    if not WA_TOKEN or not WA_PHONE_ID:
        log.warning("WhatsApp credentials not set. Skipping send.")
        return False

    # WhatsApp max single message = 4096 chars
    chunks = [text[i:i+4000] for i in range(0, len(text), 4000)]

    async with httpx.AsyncClient(timeout=15.0) as client:
        for chunk in chunks:
            try:
                r = await client.post(
                    WA_API_URL,
                    headers={
                        "Authorization": f"Bearer {WA_TOKEN}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "messaging_product": "whatsapp",
                        "to": to,
                        "type": "text",
                        "text": {"body": chunk, "preview_url": False},
                    }
                )
                if not r.is_success:
                    log.error(f"WhatsApp API error {r.status_code}: {r.text}")
                    return False
            except Exception as e:
                log.error(f"WhatsApp send error: {e}")
                return False
    return True


async def send_whatsapp_template(to: str, template_name: str, lang_code: str = "en_US") -> bool:
    """Send a pre-approved template message (for outbound first contact)"""
    if not WA_TOKEN or not WA_PHONE_ID:
        return False
    async with httpx.AsyncClient(timeout=15.0) as client:
        try:
            r = await client.post(
                WA_API_URL,
                headers={
                    "Authorization": f"Bearer {WA_TOKEN}",
                    "Content-Type": "application/json",
                },
                json={
                    "messaging_product": "whatsapp",
                    "to": to,
                    "type": "template",
                    "template": {
                        "name": template_name,
                        "language": {"code": lang_code}
                    }
                }
            )
            return r.is_success
        except Exception as e:
            log.error(f"Template send error: {e}")
            return False


async def mark_as_read(message_id: str) -> bool:
    """Mark incoming message as read (shows double blue tick)"""
    if not WA_TOKEN or not WA_PHONE_ID:
        return False
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            r = await client.post(
                WA_API_URL,
                headers={
                    "Authorization": f"Bearer {WA_TOKEN}",
                    "Content-Type": "application/json",
                },
                json={
                    "messaging_product": "whatsapp",
                    "status": "read",
                    "message_id": message_id,
                }
            )
            return r.is_success
        except Exception:
            return False
