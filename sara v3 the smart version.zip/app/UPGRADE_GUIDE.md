# Sara v3.0 — Upgrade Guide

## What Changed

### 1. Knowledge Base — Now Actually Works

The core problem was that `chat_handler.py` only checked the knowledge base when keywords like "document", "pdf", "file" appeared. Now:

- **Every message** queries the KB using TF-IDF scoring
- Only relevant context gets injected (score > 0)
- The LLM sees: "here is relevant info from your uploaded files, use it"
- So uploading today's NEXA report screenshot → asking "total NEXA bookings?" → it answers from the file ✅

#### How chunking works now
Files are split into 800-char overlapping chunks (200-char overlap). Each chunk is scored independently against the query. This means a large Excel with many sheets still returns the most relevant rows, not the whole file.

### 2. Physical File Deletion
When you click delete on a resource, it now:
1. Deletes the DB record + all its chunks (CASCADE)
2. Deletes the physical file from `/resources/` folder on disk ✅

### 3. Full Agent CRUD (Create/Read/Update/Delete)
Agents are now stored in SQLite (not just JSON). New endpoints:
- `POST /agent/create` — create
- `GET /agent/list` — list all
- `GET /agent/{name}` — get one
- `PUT /agent/{name}` — update
- `DELETE /agent/{name}` — delete
- `POST /agent/{name}/activate` — set as active (all others deactivated)

### 4. New DB Tables
`db.py` adds:
- `resource_chunks` — stores text chunks for each resource (linked by foreign key, CASCADE delete)
- `agents` — stores agent config in DB instead of JSON file

Run `db.init_db()` to auto-create these tables (it's called at startup).

### 5. PowerBI (.pbix) Support
`.pbix` files (ZIP-based) are now extracted: connections, data model metadata, report layout. Not full rendering (requires Power BI Desktop), but the metadata is indexed and searchable.

### 6. New Dashboard UI
Complete redesign:
- Dark sidebar navigation
- Stats overview cards
- Agent management grid with activate/edit/delete
- Drag-and-drop KB upload with progress bar
- KB Search tab with scored results
- Conversation viewer with delete
- Floating test chat widget (bottom right 💬 button)

---

## Migration Steps

### Step 1 — Replace files
```
app/
  __init__.py          → unchanged
  chat_handler.py      → REPLACE (smart KB retrieval)
  db.py                → REPLACE (adds chunks table + agents table)
  incentive_engine.py  → unchanged
  main.py              → REPLACE (full agent CRUD, physical delete)
  ollama_client.py     → unchanged
  resource_manager.py  → REPLACE (chunking, TF-IDF, PowerBI)
  telegram_bot.py      → REPLACE (fixes env var bug)
  tts.py               → unchanged
  whatsapp_client.py   → unchanged
  templates/
    dashboard.html     → REPLACE (new UI)
```

### Step 2 — Re-index existing resources
If you have existing files in the `resources/` folder, re-upload them through the dashboard so they get chunked properly. Old entries in the `resources` table won't have chunks.

Or run this one-time script:
```python
from app.db import init_db, list_resources, get_resource_content, save_resource_chunks
from app.resource_manager import _chunk_text

init_db()
for r in list_resources():
    content = get_resource_content(r['id'])
    if content:
        chunks = _chunk_text(content, r['filename'])
        save_resource_chunks(r['id'], chunks)
        print(f"Re-chunked {r['filename']}: {len(chunks)} chunks")
```

### Step 3 — Migrate agents from JSON
On first startup, if no agents exist in DB but `agent_config.json` exists, it auto-migrates the first agent. Or use the dashboard to recreate them.

---

## How to Get Best KB Retrieval

1. **Name your files clearly** — "NEXA_Daily_Report_2025-04-15.xlsx" helps the AI reference the right source
2. **Use descriptions** — when uploading, add a description like "Daily booking report for NEXA channel April 2025"  
3. **For screenshots** — pytesseract OCR must be installed: `pip install pytesseract pillow`; also install Tesseract system binary
4. **For large Excel files** — the system extracts all sheets and adds summary statistics, so "total", "sum", "average" queries work well

## Troubleshooting

**Q: KB not returning results**
- Check `/resources/list` — do chunks > 0? If 0, re-upload the file
- Try the KB Search tab with the exact keywords

**Q: pytesseract not available for images**
- `pip install pytesseract pillow`
- Install Tesseract: `sudo apt install tesseract-ocr tesseract-ocr-mal` (for Malayalam)

**Q: Agents not persisting**
- Make sure `db.init_db()` runs at startup (it does in `main.py`)
- Check `sara.db` exists and has the `agents` table
