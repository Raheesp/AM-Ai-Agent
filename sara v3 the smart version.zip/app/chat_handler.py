"""
chat_handler.py — Unified chat logic for Sara.

Improvements:
  - ALWAYS checks knowledge base for relevant context (not just keyword-gated)
  - Smart confidence scoring: uses KB context only when relevant
  - Multi-agent aware
  - Better Malayalam + English mixed intent detection
"""

import json
import re
from typing import Optional

from app import db
from app import ollama_client as llm
from app.incentive_engine import (
    search_by_name,
    search_by_emp_code,
    parse_incentive_intent,
    current_month_incentive,
    last_n_months_incentive,
    specific_month_incentive,
    format_incentive_response,
)
from app.resource_manager import answer_from_resources

# ── Intent detection ──────────────────────────────────────────────────────────

INCENTIVE_KEYWORDS = [
    "incentive", "salary", "take home", "takehome",
    "ഇൻസെൻറ്റീവ്", "ശമ്പളം", "ലഭിക്കുക",
    "my pay", "my salary", "my earnings",
    "7 month", "12 month", "last month", "this month",
    "current month", "last 7", "last 12",
]

# Keywords that clearly signal a knowledge-base / report query
KNOWLEDGE_QUERY_KEYWORDS = [
    "total", "booking", "retail", "nexa", "arena", "sales", "report",
    "today", "yesterday", "this week", "last week", "target", "achieved",
    "how many", "how much", "what is", "tell me", "show me", "what was",
    "count", "number of", "sum", "amount", "revenue", "stock", "inventory",
    "uploaded", "document", "pdf", "file", "sheet", "excel", "policy",
    "procedure", "guide", "according to", "from the", "explain",
    "ആകെ", "ബുക്കിംഗ്", "വിൽപ്പന",  # Malayalam: total, booking, sales
]


def _is_incentive_query(text: str) -> bool:
    t = text.lower()
    return any(kw in t for kw in INCENTIVE_KEYWORDS)


def _is_knowledge_query(text: str) -> bool:
    """Detect if the question likely has an answer in the knowledge base."""
    t = text.lower()
    return any(kw in t for kw in KNOWLEDGE_QUERY_KEYWORDS)


def _extract_name_or_code(text: str) -> tuple[Optional[str], Optional[str]]:
    """Try to extract an employee code or name from user text."""
    code_match = re.search(r"\b([A-Za-z]{2}\d{4,6})\b", text)
    if code_match:
        return None, code_match.group(1).upper()

    name_match = re.search(
        r"(?:my name is|i am|this is|name[:\s]+)\s*([A-Za-z][\w\s]{1,40})",
        text, re.IGNORECASE
    )
    if name_match:
        return name_match.group(1).strip(), None

    return None, None


def detect_intent(text: str) -> str:
    t = text.lower()
    if any(x in t for x in ["buy", "car", "price", "model", "purchase"]):
        return "sales"
    if any(x in t for x in ["service", "repair", "problem", "complaint"]):
        return "service"
    if any(x in t for x in ["incentive", "salary", "take home"]):
        return "hr"
    if any(x in t for x in KNOWLEDGE_QUERY_KEYWORDS):
        return "knowledge"
    return "general"


# ── Main handler ──────────────────────────────────────────────────────────────

async def handle_message(
    phone: str,
    text: str,
    channel: str = "api",
    system_prompt: str = "",
    model: str = "llama3.1:8b",
) -> str:
    """Core message handler. Returns assistant reply as string."""
    db.save_message(phone, "user", text, channel)
    db.upsert_customer(phone, channel=channel)

    # ── 1. Load employee session ──────────────────────────────────────────────
    session = db.get_emp_session(phone)

    # ── 2. Handle disambiguation flow ────────────────────────────────────────
    if session["state"] == "awaiting_selection":
        reply = await _handle_disambiguation(phone, text, session, model, system_prompt)
        db.save_message(phone, "assistant", reply, channel)
        return reply

    # ── 3. Handle incentive queries for confirmed employees ───────────────────
    if session["state"] == "confirmed" and _is_incentive_query(text):
        reply = await _handle_incentive_query(phone, text, session, model, system_prompt)
        db.save_message(phone, "assistant", reply, channel)
        return reply

    # ── 4. Detect new employee lookup ────────────────────────────────────────
    name, code = _extract_name_or_code(text)
    if name or code:
        reply = await _handle_employee_lookup(phone, text, name, code, session, model, system_prompt)
        db.save_message(phone, "assistant", reply, channel)
        return reply

    # ── 5. Incentive queries for confirmed employee ───────────────────────────
    if session["state"] == "confirmed" and _is_incentive_query(text):
        reply = await _handle_incentive_query(phone, text, session, model, system_prompt)
        db.save_message(phone, "assistant", reply, channel)
        return reply

    # ── 6. Incentive without confirmed employee ───────────────────────────────
    if _is_incentive_query(text) and session["state"] == "idle":
        reply = (
            "Sure! To check your incentive details, could you please share your "
            "name or employee code? For example: \"My name is Salman\" or \"My code is AM02691\"."
        )
        db.set_emp_session(phone, state="awaiting_identity")
        db.save_message(phone, "assistant", reply, channel)
        return reply

    # ── 7. Handle awaiting_identity ───────────────────────────────────────────
    if session["state"] == "awaiting_identity":
        name, code = _extract_name_or_code(text)
        if name or code:
            reply = await _handle_employee_lookup(phone, text, name, code, session, model, system_prompt)
            db.save_message(phone, "assistant", reply, channel)
            return reply
        bare_name = text.strip()
        if len(bare_name.split()) <= 4 and bare_name.replace(" ", "").isalpha():
            reply = await _handle_employee_lookup(phone, text, bare_name, None, session, model, system_prompt)
            db.save_message(phone, "assistant", reply, channel)
            return reply

    # ── 8. ALWAYS try knowledge base (not just when keyword matches) ──────────
    # For short/casual questions, still check KB. Score-based filtering ensures
    # only relevant context is injected.
    resource_context = answer_from_resources(text, top_k=5)
    
    history = db.get_history(phone, limit=20)
    
    if resource_context:
        # We have relevant KB content — inject it into the LLM context
        context_system = (
            f"{system_prompt}\n\n"
            "== KNOWLEDGE BASE CONTEXT ==\n"
            "You have access to the following information from uploaded documents. "
            "Prioritize this data when answering questions about sales, bookings, reports, "
            "or any specific numbers/facts. If the answer is clearly in the context, "
            "use it directly. If not found, say so honestly.\n\n"
            f"{resource_context}\n"
            "== END KNOWLEDGE BASE ==\n\n"
            "Answer the user's question using the above context when relevant. "
            "If quoting data, mention the source document name."
        )
        reply = await llm.chat(
            history + [{"role": "user", "content": text}],
            system=context_system,
            model=model,
        )
    else:
        # No KB context — normal conversation
        reply = await llm.chat(
            history + [{"role": "user", "content": text}],
            system=system_prompt,
            model=model,
        )

    db.save_message(phone, "assistant", reply, channel)
    return reply


# ── Employee Lookup ───────────────────────────────────────────────────────────

async def _handle_employee_lookup(
    phone, text, name, code, session, model, system_prompt
) -> str:
    if code:
        emp = search_by_emp_code(code)
        if emp:
            db.set_emp_session(phone, state="confirmed", selected_emp=json.dumps(emp))
            return (
                f"Got it! I found you — **{emp['name']}** ({emp['emp_code']}), "
                f"{emp['designation']} at {emp['branch']} ({emp['channel']}).\n\n"
                "What would you like to know? You can ask things like:\n"
                "• \"What is my current month incentive?\"\n"
                "• \"What is my last 7 months incentive?\"\n"
                "• \"Show me my April 2025 incentive\""
            )
        else:
            return f"I couldn't find any employee with code **{code}**. Please double-check and try again."

    if name:
        matches = search_by_name(name)
        if not matches:
            return (
                f"I couldn't find anyone named **{name}** in our records. "
                "Could you please check the spelling or provide your employee code?"
            )
        if len(matches) == 1:
            emp = matches[0]
            db.set_emp_session(phone, state="confirmed", selected_emp=json.dumps(emp))
            return (
                f"Found you! **{emp['name']}** ({emp['emp_code']}), "
                f"{emp['designation']} at {emp['branch']} ({emp['channel']}).\n\n"
                "What would you like to know about your incentives?"
            )
        db.set_emp_session(
            phone, state="awaiting_selection",
            search_query=name, candidates=matches,
        )
        lines = [f"I found {len(matches)} employees matching **{name}**. Which one are you?\n"]
        for i, emp in enumerate(matches, 1):
            lines.append(
                f"{i}. **{emp['name']}** ({emp['emp_code']}) — "
                f"{emp['designation']}, {emp['branch']} Branch, {emp['channel']}"
            )
        lines.append(
            "\nPlease reply with the **number**, your **employee code**, or more details "
            "like your **branch** or **showroom** (ARENA/NEXA) to identify yourself."
        )
        return "\n".join(lines)

    return "Could you please share your name or employee code so I can look you up?"


# ── Disambiguation ────────────────────────────────────────────────────────────

async def _handle_disambiguation(phone, text, session, model, system_prompt) -> str:
    candidates = session["candidates"]
    t = text.strip().lower()

    num_match = re.match(r"^(\d+)$", t)
    if num_match:
        idx = int(num_match.group(1)) - 1
        if 0 <= idx < len(candidates):
            emp = candidates[idx]
            db.set_emp_session(phone, state="confirmed", selected_emp=json.dumps(emp))
            return (
                f"Perfect! Confirmed — **{emp['name']}** ({emp['emp_code']}), "
                f"{emp['designation']} at {emp['branch']} ({emp['channel']}).\n"
                "What would you like to know about your incentives?"
            )

    code_match = re.search(r"\b([A-Za-z]{2}\d{4,6})\b", text, re.IGNORECASE)
    if code_match:
        code = code_match.group(1).upper()
        for emp in candidates:
            if emp["emp_code"].upper() == code:
                db.set_emp_session(phone, state="confirmed", selected_emp=json.dumps(emp))
                return (
                    f"Got it! **{emp['name']}** ({emp['emp_code']}) confirmed.\n"
                    "What would you like to know about your incentives?"
                )

    for emp in candidates:
        if emp["branch"].lower() in t:
            db.set_emp_session(phone, state="confirmed", selected_emp=json.dumps(emp))
            return (
                f"Found you by branch — **{emp['name']}** ({emp['emp_code']}), "
                f"{emp['designation']} at {emp['branch']} ({emp['channel']}).\n"
                "What would you like to know?"
            )

    for channel_kw in ["arena", "nexa"]:
        if channel_kw in t:
            filtered = [e for e in candidates if e["channel"].lower() == channel_kw]
            if len(filtered) == 1:
                emp = filtered[0]
                db.set_emp_session(phone, state="confirmed", selected_emp=json.dumps(emp))
                return (
                    f"Got it! **{emp['name']}** ({emp['emp_code']}) from {emp['channel']} confirmed.\n"
                    "What would you like to know?"
                )
            elif len(filtered) > 1:
                lines = [f"There are still {len(filtered)} employees in {channel_kw.upper()}:\n"]
                for i, e in enumerate(filtered, 1):
                    lines.append(f"{i}. **{e['name']}** ({e['emp_code']}) — {e['branch']}")
                lines.append("\nPlease pick a number or share your employee code.")
                db.set_emp_session(phone, state="awaiting_selection", candidates=filtered)
                return "\n".join(lines)

    return (
        "I'm not sure which one is you. Please reply with:\n"
        "• The **number** from the list above\n"
        "• Your **employee code** (e.g., AM02691)\n"
        "• Your **branch name** or **ARENA/NEXA** showroom"
    )


# ── Incentive Query ───────────────────────────────────────────────────────────

async def _handle_incentive_query(phone, text, session, model, system_prompt) -> str:
    try:
        emp = json.loads(session["selected_emp"])
    except Exception:
        db.clear_emp_session(phone)
        return "Session expired. Please share your name or employee code again."

    intent = parse_incentive_intent(text)

    if intent["type"] == "current":
        data = current_month_incentive(emp["emp_code"])
    elif intent["type"] == "last_n":
        data = last_n_months_incentive(emp["emp_code"], intent["months"])
    elif intent["type"] == "specific":
        from datetime import datetime
        import calendar
        month_abbr = intent["month"]
        year_str = intent.get("year", str(datetime.now().year))
        yr = int(year_str)
        month_num = list(calendar.month_abbr).index(month_abbr)
        if month_num >= 4:
            fy = f"{yr}-{str(yr+1)[2:]}"
        else:
            fy = f"{yr-1}-{str(yr)[2:]}"
        data = specific_month_incentive(emp["emp_code"], month_abbr, fy)
    else:
        data = current_month_incentive(emp["emp_code"])

    summary = format_incentive_response(data, intent)

    history = db.get_history(phone, limit=4)
    lm_prompt = (
        f"The user asked: \"{text}\"\n\n"
        f"Here is the incentive data retrieved:\n{summary}\n\n"
        "Present this information naturally and warmly to the employee. "
        "You may add a brief encouraging comment based on their performance. "
        "Keep it concise. Use the same language the user is using."
    )
    messages = history + [{"role": "user", "content": lm_prompt}]
    reply = await llm.chat(messages, system=system_prompt, model=model)
    return reply
