"""
db.py — SQLite database layer for Sara
Handles customers, messages, call_logs, and new resource knowledge base
"""

import sqlite3
import os
from datetime import datetime

DB_PATH = os.getenv("DB_PATH", "sara.db")


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.executescript("""
    CREATE TABLE IF NOT EXISTS customers (
        phone     TEXT PRIMARY KEY,
        name      TEXT DEFAULT '',
        channel   TEXT DEFAULT 'api',
        preferred_lang TEXT DEFAULT 'Malayalam',
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS messages (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        phone     TEXT NOT NULL,
        role      TEXT NOT NULL,
        content   TEXT NOT NULL,
        channel   TEXT DEFAULT 'api',
        timestamp TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS call_logs (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        phone        TEXT NOT NULL,
        status       TEXT,
        duration_sec INTEGER DEFAULT 0,
        summary      TEXT DEFAULT '',
        called_at    TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS resources (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        filename    TEXT NOT NULL,
        file_type   TEXT NOT NULL,
        content     TEXT NOT NULL,
        description TEXT DEFAULT '',
        uploaded_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS employee_sessions (
        phone          TEXT PRIMARY KEY,
        state          TEXT DEFAULT 'idle',
        search_query   TEXT DEFAULT '',
        candidates     TEXT DEFAULT '[]',
        selected_emp   TEXT DEFAULT '',
        last_updated   TEXT DEFAULT (datetime('now'))
    );
    """)

    conn.commit()
    conn.close()


# ── Messages ────────────────────────────────────────────────────────────────

def save_message(phone: str, role: str, content: str, channel: str = "api"):
    conn = get_conn()
    conn.execute(
        "INSERT INTO messages (phone, role, content, channel) VALUES (?, ?, ?, ?)",
        (phone, role, content, channel),
    )
    conn.commit()
    conn.close()


def get_history(phone: str, limit: int = 20) -> list[dict]:
    conn = get_conn()
    rows = conn.execute(
        "SELECT role, content FROM messages WHERE phone=? ORDER BY id DESC LIMIT ?",
        (phone, limit),
    ).fetchall()
    conn.close()
    return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]


# ── Customers ────────────────────────────────────────────────────────────────

def upsert_customer(phone: str, name: str = "", channel: str = "api", lang: str = "Malayalam"):
    conn = get_conn()
    conn.execute("""
        INSERT INTO customers (phone, name, channel, preferred_lang)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(phone) DO UPDATE SET
            name = CASE WHEN excluded.name != '' THEN excluded.name ELSE name END,
            channel = excluded.channel,
            updated_at = datetime('now')
    """, (phone, name, channel, lang))
    conn.commit()
    conn.close()


# ── Resources (Knowledge Base) ───────────────────────────────────────────────

def save_resource(filename: str, file_type: str, content: str, description: str = ""):
    conn = get_conn()
    # Replace existing resource with same filename
    conn.execute("DELETE FROM resources WHERE filename = ?", (filename,))
    conn.execute(
        "INSERT INTO resources (filename, file_type, content, description) VALUES (?, ?, ?, ?)",
        (filename, file_type, content, description),
    )
    conn.commit()
    conn.close()


def list_resources() -> list[dict]:
    conn = get_conn()
    rows = conn.execute(
        "SELECT id, filename, file_type, description, uploaded_at FROM resources ORDER BY uploaded_at DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_resource_content(resource_id: int) -> str | None:
    conn = get_conn()
    row = conn.execute("SELECT content FROM resources WHERE id=?", (resource_id,)).fetchone()
    conn.close()
    return row["content"] if row else None


def search_resources(query: str) -> list[dict]:
    """Simple keyword search across all resource content."""
    conn = get_conn()
    rows = conn.execute(
        "SELECT id, filename, file_type, content FROM resources"
    ).fetchall()
    conn.close()
    query_lower = query.lower()
    results = []
    for r in rows:
        if query_lower in r["content"].lower():
            # Return snippet around match
            content = r["content"]
            idx = content.lower().find(query_lower)
            snippet = content[max(0, idx - 200): idx + 500]
            results.append({
                "id": r["id"],
                "filename": r["filename"],
                "file_type": r["file_type"],
                "snippet": snippet,
            })
    return results


def delete_resource(resource_id: int):
    conn = get_conn()
    conn.execute("DELETE FROM resources WHERE id=?", (resource_id,))
    conn.commit()
    conn.close()


# ── Employee Sessions ────────────────────────────────────────────────────────

def get_emp_session(phone: str) -> dict:
    conn = get_conn()
    row = conn.execute(
        "SELECT * FROM employee_sessions WHERE phone=?", (phone,)
    ).fetchone()
    conn.close()
    if row:
        import json
        return {
            "state": row["state"],
            "search_query": row["search_query"],
            "candidates": json.loads(row["candidates"]),
            "selected_emp": row["selected_emp"],
        }
    return {"state": "idle", "search_query": "", "candidates": [], "selected_emp": ""}


def set_emp_session(phone: str, state: str, search_query: str = "",
                    candidates: list = None, selected_emp: str = ""):
    import json
    conn = get_conn()
    conn.execute("""
        INSERT INTO employee_sessions (phone, state, search_query, candidates, selected_emp)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(phone) DO UPDATE SET
            state=excluded.state,
            search_query=excluded.search_query,
            candidates=excluded.candidates,
            selected_emp=excluded.selected_emp,
            last_updated=datetime('now')
    """, (phone, state, search_query, json.dumps(candidates or []), selected_emp))
    conn.commit()
    conn.close()


def clear_emp_session(phone: str):
    conn = get_conn()
    conn.execute("DELETE FROM employee_sessions WHERE phone=?", (phone,))
    conn.commit()
    conn.close()
