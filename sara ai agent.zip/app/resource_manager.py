"""
resource_manager.py — Knowledge base for Sara.

Handles uploading, parsing, and searching across:
  - PDF files (text extraction)
  - CSV files
  - Excel files (xlsx)
  - Plain text / markdown
  - Images (OCR via pytesseract if available)
"""

import io
import os
import traceback
from pathlib import Path
from typing import Optional

RESOURCES_DIR = os.getenv("RESOURCES_DIR", "resources")
os.makedirs(RESOURCES_DIR, exist_ok=True)


def _extract_pdf(file_bytes: bytes) -> str:
    try:
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(file_bytes))
        texts = []
        for page in reader.pages:
            t = page.extract_text()
            if t:
                texts.append(t)
        return "\n\n".join(texts)
    except Exception as e:
        return f"[PDF extraction error: {e}]"


def _extract_csv(file_bytes: bytes) -> str:
    try:
        import pandas as pd
        df = pd.read_csv(io.BytesIO(file_bytes))
        return df.to_string(index=False)
    except Exception as e:
        return f"[CSV extraction error: {e}]"


def _extract_xlsx(file_bytes: bytes) -> str:
    try:
        import pandas as pd
        xl = pd.ExcelFile(io.BytesIO(file_bytes))
        parts = []
        for sheet in xl.sheet_names:
            df = xl.parse(sheet)
            parts.append(f"=== Sheet: {sheet} ===\n{df.to_string(index=False)}")
        return "\n\n".join(parts)
    except Exception as e:
        return f"[Excel extraction error: {e}]"


def _extract_image(file_bytes: bytes) -> str:
    try:
        import pytesseract
        from PIL import Image
        img = Image.open(io.BytesIO(file_bytes))
        return pytesseract.image_to_string(img)
    except ImportError:
        return "[Image OCR not available — install pytesseract and pillow]"
    except Exception as e:
        return f"[Image extraction error: {e}]"


def extract_text(filename: str, file_bytes: bytes) -> tuple[str, str]:
    """
    Returns (file_type, extracted_text).
    """
    ext = Path(filename).suffix.lower()
    if ext == ".pdf":
        return "pdf", _extract_pdf(file_bytes)
    elif ext == ".csv":
        return "csv", _extract_csv(file_bytes)
    elif ext in (".xlsx", ".xlsm", ".xls"):
        return "excel", _extract_xlsx(file_bytes)
    elif ext in (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tiff"):
        return "image", _extract_image(file_bytes)
    elif ext in (".txt", ".md", ".log", ".rst"):
        return "text", file_bytes.decode("utf-8", errors="replace")
    else:
        # Try as text
        try:
            return "text", file_bytes.decode("utf-8", errors="replace")
        except Exception:
            return "binary", "[Cannot extract text from this file type]"


def process_and_save_resource(filename: str, file_bytes: bytes, description: str = "") -> dict:
    """
    Extract text from file and save to DB.
    Returns result info.
    """
    from app.db import save_resource
    file_type, content = extract_text(filename, file_bytes)

    if not content.strip():
        return {"success": False, "error": "Could not extract any text from the file."}

    # Save physical file to resources dir
    save_path = os.path.join(RESOURCES_DIR, filename)
    with open(save_path, "wb") as f:
        f.write(file_bytes)

    save_resource(filename, file_type, content, description)
    return {
        "success": True,
        "filename": filename,
        "file_type": file_type,
        "chars_indexed": len(content),
    }


def answer_from_resources(question: str) -> Optional[str]:
    """
    Search resources and return relevant snippets.
    Returns None if nothing found.
    """
    from app.db import search_resources
    results = search_resources(question)
    if not results:
        return None

    parts = [f"Found relevant content in {len(results)} resource(s):\n"]
    for r in results[:3]:  # Limit to top 3
        parts.append(f"📄 **{r['filename']}**\n...{r['snippet'].strip()}...\n")

    return "\n".join(parts)
