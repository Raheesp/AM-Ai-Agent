"""
Telegram bot client
- Sends messages via Bot API
- Setup: create bot via @BotFather, get token
- Set webhook: POST https://api.telegram.org/bot{TOKEN}/setWebhook?url=https://yourdomain.com/webhook/telegram
  (use ngrok for local testing: ngrok http 8000)
"""

import httpx, os, logging
from dotenv import load_dotenv
load_dotenv()
log = logging.getLogger("sara.telegram")

# ✅ Hardcoded token
TELEGRAM_TOKEN = os.getenv(TELEGRAM_TOKEN,"")
BASE_URL = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}"

async def send_telegram_message(chat_id: str, text: str) -> bool:
    """Send a text message to a Telegram chat"""
    if not TELEGRAM_TOKEN:
        log.warning("TELEGRAM_BOT_TOKEN not set. Cannot send message.")
        return False

    # Telegram max message length is 4096 chars — split if needed
    chunks = [text[i:i+4000] for i in range(0, len(text), 4000)]

    async with httpx.AsyncClient(timeout=15.0) as client:
        for chunk in chunks:
            try:
                r = await client.post(f"{BASE_URL}/sendMessage", json={
                    "chat_id": chat_id,
                    "text": chunk,
                    "parse_mode": "Markdown",
                })
                if not r.is_success:
                    # Retry without markdown if parse fails
                    await client.post(f"{BASE_URL}/sendMessage", json={
                        "chat_id": chat_id,
                        "text": chunk,
                    })
            except Exception as e:
                log.error(f"Telegram send error: {e}")
                return False
    return True


async def send_typing_action(chat_id: str):
    """Show 'typing...' indicator while processing"""
    if not TELEGRAM_TOKEN:
        return
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            await client.post(f"{BASE_URL}/sendChatAction", json={
                "chat_id": chat_id,
                "action": "typing"
            })
    except Exception:
        pass


async def set_webhook(webhook_url: str) -> dict:
    """Register your webhook URL with Telegram"""
    async with httpx.AsyncClient(timeout=10.0) as client:
        r = await client.post(f"{BASE_URL}/setWebhook", json={
            "url": webhook_url,
            "allowed_updates": ["message", "edited_message"]
        })
        return r.json()


async def get_bot_info() -> dict:
    """Get bot username and ID"""
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.get(f"{BASE_URL}/getMe")
            return r.json()
    except Exception as e:
        return {"error": str(e)}
